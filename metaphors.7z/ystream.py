import os
from yngrams import to_sorted_lists
from yabstract import yStream
from striprtf.striprtf import rtf_to_text


encoding_std = "utf-8"
encoding_ru =  'cp1251'


class ySequence(yStream):

    def __init__(self,*items):
        self.source = items

    def __iter__(self):
        return iter(self.source)

class yOutputFileLinesStream(yStream):

    def __init__(self, encoding = encoding_std,append=False, printout=False):
        self.opts( encoding, append , printout)

    def opts(self, encoding, append=False, printout=False):
        self.encoding = encoding
        self.printout = printout
        self.mode  = 'a' if append else 'w'

    def save(self):
        self.before()
        for line in self.source:
            self.action(line)
        self.after()

    def before(self):
        self.file = open(self.filename,self.mode, encoding=self.encoding)
        print("yFileLinesSaver: saving file: " , self.filename, f", mode : {self.mode}")

    def after(self):
        self.file.close()

    def action(self,line):
        self.file.write(line)
        self.file.write('\n')
        if self.printout :
            print(line)

    def __gt__(self, other):
        self.filenames = iter(other)
        self.next_out()


    def next_out(self):
        self.filename = next(self.filenames)


class yFileNamesStream(yStream):

    def __init__(self,rootdir,ext = None):
        self.init(rootdir,ext)

    def init(self,rootdir,ext = None):
        self.rootdir = rootdir
        assert isinstance(ext,str)
        self.ext = ext

    def __iter__(self):
        ext = self.ext
        for subdir, dirs, files in os.walk(self.rootdir):
            for file in files:
                if ext and file.endswith(ext):
                    filepath = subdir + os.sep + file
                    yield filepath


class yInputFileFull(yStream):

    def __init__(self, encoding=encoding_std,to_rtf=False):
        self.init(encoding,to_rtf)

    def init(self,  encoding=encoding_std ,to_rtf=False):
        self.encoding = encoding
        self.to_rtf= to_rtf

    def __iter__(self):
        for file_name in self.source:
            with (open(file_name, 'r', encoding=self.encoding) as file):
                print("yFileLinesLoader : loading file", file_name)
                text = file.read()
                if self.to_rtf:
                    text = rtf_to_text(text)
                yield text


class yPseudoTimeMarker(yStream):
    """
    marks given text with pseudo time.

    """

    default_special_words= {"," : 5 , "!" : 10, "." : 10, "?" : 10, "-" : 3}

    def __init__(self, special_units=default_special_words):
        self.init(special_units)
        self.timestamp =0
        self.words = dict()
        self.objects_per_time = []

    def init(self,  special_units=default_special_words):
        self.special_units = special_units

    def store(self):
        special_units = self.special_units
        words = self.words
        objects_per_time =self.objects_per_time

        for word in self.source:
            #if word in special_units:
            #    self.timestamp+=special_units[word]
            #else:
            #    time_vector = words.setdefault(word,[])
            #    time_vector.append(self.timestamp)
            #    self.timestamp+=1
            self.objects_per_time.append(word)
            time_vector = words.setdefault(word, [])
            time_vector.append(self.timestamp)
            self.timestamp +=1




    def __iter__(self):
        for word,vector in self.words.items():
            yield word,vector


    def nearest_words_list(self, word, near = 1):
        assert word in self.words
        time_vector = self.words[word]
        near_words = dict()
        for time_stamp in time_vector:
            for near_time in range (max(0,time_stamp-near), time_stamp):
                near_word = self.objects_per_time[near_time]
                count = near_words.setdefault((near_word, "before"),0)
                near_words[(near_word, "before")] = count+1
                #near_words.append((self.objects_per_time[near_time], "before"))
            for near_time in range(time_stamp + 1 , min(len(self.objects_per_time), time_stamp + near+1)):
                near_word = self.objects_per_time[near_time]
                count = near_words.setdefault((near_word, "after"),0)
                near_words[(near_word, "after")] = count+1

                #near_words.append((self.objects_per_time[near_time], "after"))
        return near_words

    def nearest_all_list_cut(self, trim = 30):
        self.words_nearest_lists = dict()
        for word in self.words.keys():
            near_words_dict = self.nearest_words_list(word)
            near_words_list = sorted(near_words_dict.items(), key= lambda kw: -kw[1])[:trim]
            self.words_nearest_lists[word] = near_words_list




    from random import choice
    def random_nearest(self, range = 1):
        word = self.choice(self.objects_per_time)
        print("choosed word : " , word )
        print( self.nearest_words_list(word,range))




    def nearest_words_vector_distance(self):
        self.nearest = dict()
        keys = list(self.words)
        len_keys = len(keys)
        for i in range(len_keys-1):
            vector = self.words[keys[i]]
            min_dist = 1000000
            min_index = -1
            for j in range(i+1,len_keys):
                next_vector = self.words[keys[j]]
                this_dist = self.vector_min_distance(vector,next_vector)
                if this_dist < min_dist:
                    min_dist = this_dist
                    min_index = j
            self.nearest[keys[i]] = (min_dist, keys[min_index])

    def iter_nearest(self):
        for key, value in self.nearest.items():
            yield key, value





    def vector_min_distance(self,vector,next_vector):
        index = 0
        next_index = 0
        len_vector = len(vector)
        len_next_vector = len(next_vector)
        dist = 1000000
        while index < len_vector and next_index < len_next_vector:
            this_dist = vector[index] - next_vector[next_index]
            if this_dist < 0:
                index+=1
            else:
                next_index+=1
            abs_dist = abs(this_dist)
            if abs_dist < dist:
                dist = abs_dist
        return dist











class yInputFileLinesStream(yStream):
    """
    Class what represents an input file stream of lines of this file,
    splitted by file.readlines(), stripped with line.strip() and
    empty strings are skipped
    init variables:
    - encoding
    - max_lines - amount of lines, read from the file. put negative value for all lines from a file
    """

    def __init__(self, encoding=encoding_std, max_lines = -1):
        self.init(  encoding, max_lines)

    def init(self,  encoding, max_lines = -1):
        self.encoding = encoding
        self.max_lines = max_lines

    def __iter__(self):
        for token in self.source:
            with (open(token, 'r', encoding=self.encoding) as file):
                print("yFileLinesLoader : loading file" , token)
                max_lines = self.max_lines
                for line in file.readlines():
                    line = line.strip()
                    if line:
                        if max_lines == 0:
                            break
                        max_lines -=1
                        yield line




class yFilterLastLineItemStream(yStream):

    def __init__(self,  split_symbol):
        self.opts(split_symbol)

    def opts(self, split_symbol):
        self.split_symbol = split_symbol

    def __iter(self):
        for line in self.source:
            items = line.split(self.split_symbol)
            yield items[-1]

class yUniqueStream(yStream):

    def __init__(self):
        self.last_hash = 0

    def __iter__(self):
        for item in self.source:
            this_hash = hash(item)
            if this_hash != self.last_hash:
                self.last_hash = this_hash
                yield item

class yNGramsLinesLoad:

    def __init__(self, split_key_value, split_list):
        self.conf(split_key_value,split_list)

    def conf(self, split_key_value, split_list):
        self.split_key_value = split_key_value
        self.split_list =split_list


    def __iter__(self):

        for line in self.source:
            line = line.strip()
            if line:
                key, vector = line.split(self.split_key_value, maxsplit = 1)
                key, vector = key.strip(), vector.strip()

                yield key, None, None
                for item_pair in vector.split(self.split_list):
                    item_pair = item_pair.strip()
                    item , weight = item_pair.split(self.split_key_value)
                    item, weight = item.strip(), weight.strip()
                    weight = int(weight)
                    yield None, item, weight


class yNGramsTagsLoad(yStream):

    def __init__(self, item_split ="~", tag_split = "|"):
        self.init(item_split,tag_split)

    def init(self, item_split="~", tag_split = "|"):
        self.item_split = item_split
        self.tag_split = tag_split

    def __iter__(self):
        item_split = self.item_split
        tag_split = self.tag_split


        for line in self.source:
            items = line.split(item_split)
            items = [item.strip() for item in items]
            key, value = items
            key_name, *key_tags =key.split(tag_split)
            value_name, *value_tags =value.split(tag_split)
            yield key_name,key_tags,value_name,value_tags



class yNGramsRawLoad(yStream):

    def __init__(self,  split_symbol,  noweight = False):
        self.init(split_symbol, noweight)

    def init(self, split_symbol, noweight):
        self.split_symbol = split_symbol
        #self.backwards = backwards
        self.noweight = noweight

    def store2(self):
        for line in self.source:
            items = line.split(self.split_symbol)
            items = [item.strip() for item in items]
            subject, verb, *objects = items
            key = subject
            yield key, None,None
            for object in objects:
                item = verb,object
                yield None, item, 1

    def __iter__(self):
        #backwards = self.backwards
        noweight = self.noweight
        expected_len = 2 if self.noweight else 3

        for line in self.source:
            items = line.split(self.split_symbol)
            items = [item.strip() for item in items]
            if len(items) != expected_len :
                continue

            if noweight:
                key, item  = items
                weight = 1
            else:
                #if backwards:
                #     item, key, weight = items
                #else:
                #    key, item,  weight = items
                key, item, weight = items
                weight = int(weight)

            yield key, item,  weight




class yDistancesLinesStream(yStream):

    def __init__(self,dictionary,trashhold):
        self.init(dictionary,trashhold)

    def init(self,dictionary,trashhold):
        self.dictionary = dictionary
        self.trashhold = trashhold

    def __iter__(self):
        d = self.dictionary
        trashhold = self.trashhold
        keys = list(d.keys())
        len_keys = len(keys)
        for i in range(len_keys-1):
            key = keys[i]
            value = d[key]
            output_vector = []
            for j in range(i+1,len_keys):
                next_key = keys[j]
                next_value = d[next_key]
                common_keys = value.keys() & next_value.keys()
                #distance = sum(min(value[x], next_value[x]) for x in common_keys)
                distance = len(common_keys)
                if distance > 0:
                    output_vector.append((next_key, distance))
            output_vector = sorted(output_vector, key=lambda pair: -pair[1])
            output_vector = output_vector[:trashhold]
            line = self.format_output(key, output_vector)
            if line:
                yield line

    def format_output(self, key, value_pairs):
        if value_pairs:
            formatted_value = ",".join(f"{pair[0]}:{pair[1]}" for pair in value_pairs)
            line = f"{key}:{formatted_value}\n"
            return line


class yNgramToLinesStream(yStream):


    def __iter__(self):
        for key, vector in self.source:
            if vector:
                formatted_vecor = ",".join(f"{item}" for item in vector)
                line = f"{key}:{formatted_vecor}\n"
                yield line



class ySpacyTokenStream(yStream):

    en = "en_core_web_sm"
    ru = 'ru_core_news_sm'

    def __init__(self,lang_name = ru, spacy_lib = None):
        self.init(lang_name,spacy_lib)

    def init(self, lang_name = ru, spacy_lib= None):
        if spacy_lib is None:
            import spacy
            spacy_lib = spacy

        self.spacy_lib = spacy_lib
        self.lang_name = lang_name
        self.spacy_lib.prefer_gpu()
        self.nlp = self.spacy_lib.load(self.lang_name)
        self.nlp.max_length = 1500000

    def __iter__(self):
        for text in self.source:
            doc = self.nlp(text)
            for n, sentence in enumerate(doc.sents):
                for token in sentence:
                    #yield from self.yield_root_clauses(token)
                    yield token



class yClauseFilterSpacyStream(yStream):

    def __init__(self):

       self.rules = {("VERB", "ROOT") :[[("NOUN", "nsubj") ,("NOUN", "obj") ],[("PRON", "nsubj") ,("NOUN", "obj")  ],[("NOUN", "nsubj") ,("NOUN", "obl") ], ] }

    def __iter__(self):
        for token in self.source:
            rules_row = self.rules.get((token.pos_, token.dep_), None)
            if not rules_row: continue
            children_dict = {(child.pos_, child.dep_): child for  child in token.children}
            if rules_row:
                for rule_variant in rules_row:
                    found = True
                    found_children = []
                    for pos_, dep_ in rule_variant:
                        child_candidate = children_dict.get((pos_, dep_), None)
                        if child_candidate:
                            found_children.append(child_candidate.lemma_)
                        else:
                            found = False
                            break
                    if found:
                        yield token,found_children



class yClauseNaiveFilterSpacyStream(yStream):
    def __init__(self):
        pass

    def __iter__(self):
        for token in self.source:
            subject , objects,attributes = self. check_svo_attr(token)
            if subject and objects:
                for object in objects:
                    #yield "SVO", token.lemma_, subject.lemma_, object.lemma_
                    yield f"SVO|{token.lemma_}|{subject.lemma_}|{object.lemma_}"
            if attributes:
                for attr in attributes:
                    #yield "OA", token.lemma_,attr.lemma_
                    yield f"OA|{token.lemma_}|{attr.lemma_}"


    def check_svo_attr(self,token):
        subject = None
        objects = []
        attributes = []

        for child in token.children:
            if child.dep_ == "nsubj" and child.pos_ in {"NOUN","PRON" , "PROPN"}:
                subject = child
            if child.pos_ == "NOUN" and child.dep_ in {"obj","obl"}:
                objects.append(child)
            if child.dep_ in {"amod","advmod"}:
                attributes.append(child)

        return subject , objects,attributes


    def check_if(self, token):
        advcl_found = False
        if_found = False

        for child in token.children:
            if child.dep_ == "adcvl":
                for inner_child in child.children:
                    if inner_child.lemma_ == "если":
                        return True

    def check_in_case(self, token):
        pass
        #adcvl -> В - mark ? ->














class yClausesSpacy(yStream):

    en = "en_core_web_sm"
    ru = 'ru_core_news_sm'

    def __init__(self,lang_name, spacy_lib = None):


        self.init(lang_name,spacy_lib = None)

    def init(self, lang_name , spacy_lib):
        if spacy_lib is None:
            import spacy
            spacy_lib = spacy

        self.spacy_lib = spacy_lib
        self.lang_name = lang_name
        self.spacy_lib.prefer_gpu()
        self.nlp = self.spacy_lib.load(self.lang_name)

    def __iter__(self):
        for text in self.source:
            doc = self.nlp(text)
            for n, sentence in enumerate(doc.sents):
                for token in sentence:
                    #yield from self.yield_root_clauses(token)
                    yield from self.yield_token_child_pairs(token)

    def yield_token_child_pairs(self,token):
        children = list(token.children)
        for child in children:
            yield f"{token.lemma_}|{token.pos_}|{token.dep_} ~ {child.lemma_}|{child.pos_}|{child.dep_}"

    def yield_root_clauses(self, root_token):
        if root_token.dep_ != "ROOT": return
        stack = [(root_token,0)]
        while stack:
            token,depth = stack.pop()
            children = list(token.children)
            #remove unclassifyed dependencies:
            skip = False
            objects = []
            verb = None
            subject = None
            if  token.pos_ == "VERB":
                verb =  token.lemma_
            for child in children:
                if (child.pos_ == "NOUN" or child.pos_ == "PRON"or child.pos_ == "PROPN") and child.dep_ == "nsubj":
                    subject =child.lemma_
                if ((child.pos_ == "NOUN" or child.pos_ == "PRON"or child.pos_ == "PROPN") and (child.dep_ == "obj" or child.dep_ == "obl")) or  \
                    (child.pos_ == "VERB" and child.dep_ == "xcomp" ):
                    objects.append(child.lemma_)

            if subject and verb and objects:
                yield "|".join( (subject , verb, *objects))
            children.reverse()
            depth+=1
            for child in children:
                stack.append((child,depth ))



class ySplitStream(yStream):

    def __init__(self, skip = " \t\r\n" , keep = ".,:;-!?'\"", lookupLen = 256):
        self.init(skip, keep, lookupLen)


    def init(self, skip = " \t\r\n" , keep = ".,:;-!?'\"", lookupLen = 256):
        lookup = [0 for _ in range(lookupLen)]
        self.lookup = lookup
        for c in skip:
            lookup[ord(c)] = 1

        for c in keep:
            lookup[ord(c)] = -1

    def __iter__(self):
        lookup = self.lookup
        lookup_len = len(lookup)
        for text in self.source:
            assert isinstance(text, str)
            begin = 0
            for n, c in enumerate(text):
                ordc = ord(c)
                flag = lookup[ordc] if ordc < lookup_len else 0
                if flag != 0 :
                    if n > begin:
                        yield text[begin:n]
                    begin = n+1
                    if flag < 0 :
                        yield c



