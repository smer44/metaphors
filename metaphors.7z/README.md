# metaphors
This project contains different approaches
of constructing the commonsence 
knowledge system,what is 
not based on neural network.

The knowledge system should cover 
all commonsence meaning inclusive in 
best case understanding of metaphors.

This approach analyzes the idea that 
metapors can serve as generalizing 
information to build a commonsence object
hierarchy/ontology.

The commonsence meaning should be constructed
by mashine learning method.


But beyound that, other methods are included.

For example, the folder dictionaries
is constructed by hand and consist of marked words, 
what would create ontology-like "tagged" 
system. 
